# Researches
![Research](https://www.wsu.ac.za/images/2020/04/15/reseach.jpg)

This folder contains all the research conducted for this project. I have done three research topics. These are the following:
- [Backend framework](./Backend%20Framework%20Research.md) research
- [Project dependability](./Dependability%20Research.md) research
- [SSL security](./SSL%20Security%20Research.md) research