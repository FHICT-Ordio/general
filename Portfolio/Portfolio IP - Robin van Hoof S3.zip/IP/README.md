# Individual Project - Robin van Hoof S3
![Individual Project](https://cdn.sanity.io/images/e422uarq/production/016018a08eddf9bbaee619b77a92ff51051495f1-2000x945.png?fit=crop&fm=jpg&q=100&w=1200&h=630)

Whe individual part of my portfolio are split up into a few different categories. These categories are the following:
- My [products and learning outcome](./Products%20and%20learning%20outcomes.md) definitions for this project;
- My [documentation](https://github.com/FHICT-Ordio/general/tree/main/Portfolio/IP/Documentation) for this project;
- My [researches](https://github.com/FHICT-Ordio/general/tree/main/Portfolio/IP/Research) for this project;